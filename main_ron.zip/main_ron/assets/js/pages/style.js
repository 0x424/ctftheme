import $ from "jquery";
import styles from "../styles";
import times from "../times";

$(() => {
  styles();
  times();
});
